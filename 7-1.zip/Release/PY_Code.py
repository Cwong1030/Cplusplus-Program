import re
import string
import os.path
from os import path

def CountAll():
    #Opens file in read mode
    text = open("Input_File.txt", "r")
    #Creates empty dictionary to store discovered words
    dictionary = dict()

    for line in text:       #Checks each line of input file
        line = line.strip()     #remove any errant spaces and newline characters
        word = line.lower()     #Convert characters to lowercase to get a better match
        if word in dictionary:      #Verify the dictionary to see if the word is there
            dictionary[word] = dictionary[word] + 1     #Increment number of times the word appears
        else:
            dictionary[word] = 1        #Add the word with a value of 1 if it is not in the dictionary.

    #Prints contents of the dictionary
    for key in list (dictionary.keys()):
        print(key.capitalize(), ":", dictionary[key])

    #Closes opened file
    text.close()

def CountInstances(searchTerm):

    #Convert input search term to lowercase for better match
    searchTerm = searchTerm.lower()

    #Opens file in read mode
    text = open("Input_File.txt", "r")

    #Create variable to track how many times the search term has been "found"
    wordCount = 0

    #Checks each line of input file
    for line in text:
        line = line.strip()     #if there are any extra spaces or newlines, remove them
        word = line.lower()     #Convert characters to lowercase to get a better match      
        if word == searchTerm:      #Verify that the discovered word matches the user's input.
            wordCount += 1      #Increment number of times the word appears 

    #Return the number of times the search term was found, as per specification
    return wordCount

    #Close opened file
    text.close()

def CollectData():
    #Opens file in read mode
    text = open("Input_File.txt", "r")
    #Create or write the frequency.dat file.
    frequency = open("frequency.dat", "w")
    #Creates empty dictionary to store discovered words
    dictionary = dict()

    for line in text:       #Checks each line of input file
        line = line.strip()     #remove any errant spaces and newline characters
        word = line.lower()     #Convert characters to lowercase to get a better match
        if word in dictionary:      #Verify the dictionary to see if the word is there
            dictionary[word] = dictionary[word] + 1     #Increment number of times the word appears
        else:
            dictionary[word] = 1        #Add the word with a value of 1 if it is not in the dictionary.

    #Prints contents of the dictionary
    for key in list (dictionary.keys()):
        #Format the key-value pair as strings, then add a newline after each string.
        frequency.write(str(key.capitalize()) + " " + str(dictionary[key]) + "\n")

    #Closes opened file
    text.close()
    frequency.close()



    
